"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = default_1;
const util = __importStar(require("../core/util.cjs"));
const error = () => {
    const Sizable = {
        string: { unit: "پیت", verb: "بێت" },
        file: { unit: "بایت", verb: "بێت" },
        array: { unit: "دانە", verb: "بێت" },
        set: { unit: "دانە", verb: "بێت" },
        map: { unit: "دانە", verb: "بێت" },
    };
    function getSizing(origin) {
        return Sizable[origin] ?? null;
    }
    const FormatDictionary = {
        regex: "regex",
        email: "ئیمەیڵ",
        url: "بەستەر (URL)",
        emoji: "ئیمۆجی",
        uuid: "UUID",
        uuidv4: "UUIDv4",
        uuidv6: "UUIDv6",
        nanoid: "nanoid",
        guid: "GUID",
        cuid: "cuid",
        cuid2: "cuid2",
        ulid: "ULID",
        xid: "XID",
        ksuid: "KSUID",
        datetime: "ڕێکەوت و کات",
        date: "ڕێکەوت",
        time: "کات",
        duration: "ماوە",
        ipv4: "ناونیشانی IPv4",
        ipv6: "ناونیشانی IPv6",
        mac: "ناونیشانی MAC",
        cidrv4: "مەودای IPv4",
        cidrv6: "مەودای IPv6",
        base64: "دەقی base64",
        base64url: "دەقی base64url",
        json_string: "دەقی JSON",
        e164: "ژمارەی E.164",
        credit_card: "ژمارەی کارتی کرێدیت",
        iban: "IBAN",
        jwt: "JWT",
        template_literal: "تێکردە",
    };
    // type names: missing keys = do not translate (use raw value via ?? fallback)
    const TypeDictionary = {
        nan: "NaN",
        string: "نووسین",
        number: "ژمارە",
        boolean: "boolean",
        array: "array",
        object: "object",
        date: "ڕێکەوت",
        integer: "ژمارە",
        float: "ژمارە",
        null: "null",
        undefined: "undefined",
        function: "function",
        symbol: "symbol",
        unknown: "unknown",
        promise: "promise",
        void: "void",
        never: "never",
        map: "map",
        set: "set",
    };
    return (issue) => {
        switch (issue.code) {
            case "invalid_type": {
                const expected = TypeDictionary[issue.expected] ?? issue.expected;
                const receivedType = util.parsedType(issue.input);
                const received = TypeDictionary[receivedType] ?? receivedType;
                const postfix = ["ا", "و", "ۆ", "وو", "ە", "ی", "ێ"].some((p) => received.endsWith(p)) ? "یە" : "ە";
                const isEnglish = /^[a-zA-Z]+$/.test(received);
                if (receivedType === "null" || receivedType === "undefined")
                    return `داواکراوە`;
                return `چاوەڕوانکراوە ${expected} بێت، بەڵام ${received}${isEnglish ? "" : postfix}`;
            }
            case "invalid_value":
                if (issue.values.length === 1)
                    return `بەهاکە نادرووستە: چاوەڕوانکراوە ${util.stringifyPrimitive(issue.values[0])} بێت`;
                return `هەڵبژاردەی نادروست: چاوەڕوانکراوە یەکێک بێت لە ${util.joinValues(issue.values, "|")}`;
            case "too_big": {
                const sizing = getSizing(issue.origin);
                if (sizing)
                    return `پێویستە بە لایەنی زۆرەوە ${issue.maximum.toString()} ${sizing.unit} ${sizing.verb}`;
                return `پێویستە بە لایەنی زۆرەوە ${issue.maximum.toString()} بێت`;
            }
            case "too_small": {
                const sizing = getSizing(issue.origin);
                if (sizing)
                    return `پێویستە بە لایەنی کەمەوە ${issue.minimum.toString()} ${sizing.unit} ${sizing.verb}`;
                return `پێویستە بە لایەنی کەمەوە ${issue.minimum.toString()} بێت`;
            }
            case "invalid_format": {
                const _issue = issue;
                if (_issue.format === "starts_with") {
                    return `دەقی نادروست: پێویستە دەستپێبکات بە "${_issue.prefix}"`;
                }
                if (_issue.format === "ends_with")
                    return `دەقی نادروست: پێویستە کۆتاییبێت بە "${_issue.suffix}"`;
                if (_issue.format === "includes")
                    return `دەقی نادروست: پێویستە "${_issue.includes}" لەخۆبگرێت`;
                if (_issue.format === "regex")
                    return `دەقی نادروست: پێویستە لەگەڵ پاتێرنی ${_issue.pattern} بگونجێت`;
                return `بەهای ${FormatDictionary[_issue.format] ?? issue.format} نادروستە`;
            }
            case "not_multiple_of":
                return `ژمارەی نادروست: دەبێت چەند هێندە بێت بۆ ${issue.divisor}`;
            case "unrecognized_keys":
                return `کلیلی نەناسراو: ${util.joinValues(issue.keys, ", ")}`;
            case "invalid_key":
                return `کلیلی نادروست لە ${issue.origin}`;
            case "invalid_union":
                if (issue.options && Array.isArray(issue.options) && issue.options.length > 0) {
                    const opts = issue.options.map((o) => `'${o}'`).join(" | ");
                    return `بەهای نەناسراو هەیە. بەهای چاوەڕوانکراو: ${opts}`;
                }
                return "یەکگرتنی نادروست";
            case "invalid_element":
                return `${issue.origin} بەهاکە نادروستە`;
            default:
                return `تێکردەی نادروست`;
        }
    };
};
function default_1() {
    return {
        localeError: error(),
    };
}
module.exports = exports.default;
