"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";

import { getMe } from "@/services/authService";
import useAuthStore from "@/store/authStore";

export default function AccountLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  const router = useRouter();

  const [isCheckingAuth, setIsCheckingAuth] = useState(true);

  useEffect(() => {
    const checkUser = async () => {
      try {
        const data = await getMe();

        useAuthStore.getState().setUser(data.user);

        setIsCheckingAuth(false);
      } catch {
        useAuthStore.getState().clearUser();

        router.replace("/login");
      }
    };

    checkUser();
  }, [router]);

  if (isCheckingAuth) {
    return (
      <div className="flex min-h-[60vh] items-center justify-center">
        <p className="text-sm text-neutral-500">
          در حال بررسی حساب کاربری...
        </p>
      </div>
    );
  }

  return <>{children}</>;
}

